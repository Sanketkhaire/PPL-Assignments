#include <iostream>
using namespace std;

void incr(int *a){
	*a = 3;
}

int main(){
	int *a, b = 6;
	a = &b;
	incr(a);
	return 0;
}
